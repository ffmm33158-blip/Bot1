__all__ = [
    "start",
    "notes",
    "search",
    "stats",
    "backup",
    "add",
    "edit",
]